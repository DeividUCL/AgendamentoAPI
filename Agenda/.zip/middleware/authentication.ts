interface AuthState {
  isAuthenticated: boolean;
}

export default defineNuxtRouteMiddleware((to) => {
  const auth = useState<AuthState>('auth', () => ({ isAuthenticated: false }));

  if (!auth.value.isAuthenticated) {
    return navigateTo('/login');
  }

  if (to.path !== '/dashboard') {
    return navigateTo('/dashboard');
  }
});