<template>
  <div>
    <span>BARBEARIA ALFA</span>
  </div>
</template>

<script setup lang="ts">
useHead({
  link: [
    {
      rel: 'preconnect',
      href: 'https://fonts.googleapis.com'
    },
    {
      rel: 'stylesheet',
      href: 'https://fonts.googleapis.com/css2?family=Rye&display=swap',
      crossorigin: ''
    }
  ]
})
</script>

<style scoped>
span {
  font-family: 'Rye', cursive;
}
</style>
