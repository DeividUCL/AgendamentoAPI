<script lang="ts" setup></script>

<template>
    <div>
        Main
    </div>
</template>

<style scoped></style>