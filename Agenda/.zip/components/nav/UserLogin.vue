<template>
    <NuxtLink class="mr-2 no-underline" to="/login">Login</NuxtLink>
    <Avatar icon="pi pi-user" class="mr-2" size="xlarge" shape="circle" />
</template>