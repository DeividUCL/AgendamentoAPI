<template>
  <NavMenuTop />
</template>
