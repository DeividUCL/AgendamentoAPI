import { defineNuxtConfig } from 'nuxt/config'
export default defineNuxtConfig({
  devtools: { enabled: false },
  css: [
    'primeflex/primeflex.css',
    'primevue/resources/themes/lara-dark-purple/theme.css',
    'primevue/resources/primevue.min.css',
    'primevue/resources/primevue.css',
    'primeicons/primeicons.css',
  ],
  build: {
    transpile: ['primevue']
  },
  modules: [
    '@nuxt/content',
    '@primevue/nuxt-module',
    '@sidebase/nuxt-auth'
  ],

  primevue: {
    usePrimeVue: true
  },

  auth: {
    isEnabled: true,
    disableServerSideAuth: false,
    originEnvKey: 'AUTH_ORIGIN',
    baseURL: 'http://localhost:5267/',
    provider: {
      type: 'local',
      token: {
        signInResponseTokenPointer: 'token',
        type: 'Bearer',
        cookieName: 'auth.token',
        headerName: 'Authorization',
        maxAgeInSeconds: 1800,
        sameSiteAttribute: 'lax',
        cookieDomain: 'localhost:5267',
        secureCookieAttribute: false,
        httpOnlyCookieAttribute: false,
      },
      endpoints: {
        signIn: { path: 'v1/account/login', method: 'post' },
        signUp: { path: 'usuario', method: 'post' },
      },
      pages: {
        login: '/login'
      },
    },
  },

  content: {
    locales: ['pt-br'],
  },

})