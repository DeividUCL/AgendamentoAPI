<script setup lang="ts">
definePageMeta({
    middleware: 'auth',
});

const {
    status,
    data,
    signIn,
    signOut
} = useAuth()

const username = ref('')
const senha = ref('')
const errorMessage = ref('')

const login = async () => {

    console.log('Tentando fazer login com:', { username: username.value, senha: senha.value });
    try {
        await signIn({
            provider: 'local',
            data: {
                username: username.value,
                senha: senha.value
            },
            url: 'http://localhost:5267/v1/account/login'
        })
        errorMessage.value = ''
        console.log('Resposta do servidor:', errorMessage);
    } catch (error) {
        console.error('Erro ao tentar fazer login:', error);
        errorMessage.value = 'O acesso falhou. Verifique o login e senha.'
    }
}

const logout = async () => {
    await signOut()
}

const traduzirStatus = (status: string) => {
    switch (status) {
        case 'authenticated':
            return 'está Conectado';
        case 'unauthenticated':
            return 'não está Conectado';
        case 'loading':
            return 'carregando';
        default:
            return status;
    }
};
</script>

<template>
    <div class="login">
        <Card>
            <template #header>
                <div class="flex justify-content-center align-items-center">
                    <img class="p-4" alt="login header" src="../public/fingerprint-identity.jpg" />
                </div>
            </template>
            <template #title>Acesse a Agenda</template>
            <template #subtitle>Barbearia Alfa</template>
            <template #content>
                <p class="m-0">
                <p>{{ traduzirStatus(status) }}</p>
                <div v-if="data">
                    Olá {{ data?.id.valueOf() }}
                    <button @click="logout">Logout</button>
                </div>
                <div v-else>
                    <form @submit.prevent="login">
                        <InputText v-model="username" type="text" placeholder="Login" required />
                        <br /><br />
                        <Password v-model="senha" promptLabel="insira a senha." type="password" placeholder="Senha"
                            required toggleMask />
                        <br /><br />
                        <Button type="submit">Entrar</Button>
                        <p v-if="errorMessage">{{ errorMessage }}</p>
                    </form>
                </div>

                </p>
            </template>
            <template #footer>

                <div class="flex justify-content-center gap-3">
                    <NuxtLink class="no-underline" to="/cadastro">
                        Cadastre-se
                        <Avatar icon="pi pi-user" size="normal" />
                    </NuxtLink>
                </div>
            </template>
        </Card>
    </div>
</template>

<style scoped>
.login {
    display: flex;
    justify-content: center;
    align-items: center;
    height: calc(100vh - 200px);
}
</style>
