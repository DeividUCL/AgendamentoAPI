<template>
  <main>
    <ContentDoc />
  </main>
</template>

<script setup lang="ts">
</script>