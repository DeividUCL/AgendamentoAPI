<template>
    <div>
        CADASTRO
        <br />
        <NuxtLink to="/login">Efetuar Login</NuxtLink>
    </div>
</template>