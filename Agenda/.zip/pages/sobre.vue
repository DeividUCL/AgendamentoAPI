<template>
  <div>
    Sobre
  </div>
</template>

<script lang="ts" setup></script> 
