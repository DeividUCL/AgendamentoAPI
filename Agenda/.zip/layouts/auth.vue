<template>
  <AppHeader />
  <div class="flex align-items-center justify-content-center">
    <slot></slot>
  </div>
  <AppFooter />
</template>
