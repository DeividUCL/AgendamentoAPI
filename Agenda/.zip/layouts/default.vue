<template>
    <div>
        <AppHeader />
        <slot></slot>
        <AppFooter />
    </div>
</template>

<style></style>
