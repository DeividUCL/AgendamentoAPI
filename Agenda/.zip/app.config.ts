export default defineAppConfig({
  content: {
    files: [
      './src/**/*.html',
      './src/**/*.vue',
      './src/**/*.jsx',
    ],
  },
})
